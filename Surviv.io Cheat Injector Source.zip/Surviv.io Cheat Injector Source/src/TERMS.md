## Terms

-   Presented as-is, meaning you are not entitled to more features.
-   Support may be canceled at any time
-   Do not sell this free product, c'mon that's just wrong.
-   No one is responsible for bans or detections except you.

© 2019 IceHacks
