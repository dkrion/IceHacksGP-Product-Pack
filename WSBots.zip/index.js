const WebSocket = require("ws");
const wss = new WebSocket.Server({ port: 5632 });
const request = require("request");
const crypto = require("crypto");
const argv = require("yargs").argv;
console.log(argv.mobile == "true")
require("./t");
require("./source");

const data = getModule("989ad62a");
const d = class {
	constructor() {
		this.activeCount = 0;
		this.creator = {
			type: class {
				constructor() { }

				o() {
					this.updatedData = !1;
				}

				n() { }

				c(e) {
					this.pos = e.re
						? Object.assign({}, e.re)
						: e.pos
							? Object.assign({}, e.pos)
							: false;
					this.dir = e.oe
						? Object.assign({}, e.oe)
						: e.dir
							? Object.assign({}, e.dir)
							: false;
					this.dead = e.he
						? Object.assign({}, e.he)
						: e.dead
							? Object.assign({}, e.dead)
							: false;
					this.layer = e.pe
						? Object.assign({}, e.pe)
						: e.dead
							? Object.assign({}, e.layer)
							: false;
					this.type = e.type || false;
					this.rad = e.rad || false;
					this.id = e.__id;
				}
			},
		};
		this.yt = [];
	}

	alloc() {
		for (var e = null, t = 0; t < this.yt.length; t++)
			if (!this.yt[t].active) {
				e = this.yt[t];
				break;
			}
		return (
			e || ((e = new this.creator.type()), this.yt.push(e)),
			(e.active = !0),
			e.o(),
			this.activeCount++,
			e
		);
	}

	free(e) {
		if (
			(e.n(),
				(e.active = !1),
				this.activeCount--,
				this.yt.length > 128 && this.activeCount < this.yt.length / 2)
		) {
			for (var t = [], a = 0; a < this.yt.length; a++)
				this.yt[a].active && t.push(this.yt[a]);
			this.yt = t;
		}
	}

	p() {
		return this.yt;
	}
};
const Creator = class {
	constructor() {
		this.idToObj = {};
		this.types = {
			1: new d(),
			2: new d(),
			3: new d(),
			4: new d(),
			5: new d(),
			6: new d(),
			7: new d(),
			8: new d(),
			9: new d(),
			10: new d(),
			11: new d(),
		};
		this.seenCount = 0;
	}

	registerType(e, t) {
		this.types[e] = t;
	}

	getObjById(e) {
		return this.idToObj[e];
	}

	getTypeById(e, t) {
		var a = this.getObjById(e);
		if (!a) {
			return 0;
		}
		return a.__type;
	}

	updateObjFull(e, t, a, i) {
		var r = this.getObjById(t),
			o = !1;
		return (
			void 0 === r &&
			((r = this.types[e].alloc()),
				(r.__id = t),
				(r.__type = e),
				(this.idToObj[t] = r),
				this.seenCount++,
				(o = !0)),
			r.c(a, !0, o, i),
			r
		);
	}

	updateObjPart(e, t, a) {
		var i = this.getObjById(e);
		i ? i.c(t, !1, !1, a) : 0;
	}

	deleteObj(e) {
		var t = this.getObjById(e);
		void 0 === t
			? 0
			: (this.types[t.__type].free(t), delete this.idToObj[e]);
	}
};

let names = [
	"Player",
	"PotatoKiller",
	"xXDarkknightXx",
	"DummoDrummo",
	"Jayson",
	"crispro",
	"silent killer",
	"Nobody",
	"beastmode",
	"hacker = gay",
	"kill if GAY",
	"kobebryant",
	"Trump2020",
	"pro",
	"team code " + crypto.randomBytes(2).toString("hex"),
	"Alavengi",
	"DressyOnline",
	"Isa_No",
	"roomsdaddead",
	"best surviv",
	"steven.carasso",
	"fortnite",
	"fortnite sucks",
	"ligma",
	"YoUr MoM",
	"obama",
	"CrispyFries",
	"iHasYou",
	"AdrenYT",
	"killa_crab",
	"nibba",
	"PiCkLe JoE",
	"spegetta",
	"FishyFin",
	"Player",
	"Player",
	"Player",
	"Player2",
	"player",
	"Papi",
	"Player",
	"jews",
	"Bananamana",
	"kkk",
	"noobs",
	"dontHACK",
	"lt. killa",
	"a pro",
	"Mad Scott",
	"omega [YT]",
	"Dnlad Trmpy",
	"Burny",
	"a bot",
	"IceHacks",
	"fat cheater",
	"cheerios",
	"rooster",
	"racecar",
	"NASA PC",
	"Dayton500",
	"death to us",
	"butterfingers",
	"PewDiePie",
	"albert",
	"tom",
	"Johnny",
	"Mr Wick",
	"Terminator",
	"tomato juice",
	"kobe rip",
	"dont kill",
	"let's team",
	"Aesah",
	"fofo",
	"mrNub",
	"coronavirus",
	"ebola",
	"jackson",
	"D3n1s3",
	"Cutlass Crusher",
	"NewYork Blitz",
	"Liquid Bang",
	"Saucy Whip",
	"Crazy Knight",
	"Blaze Thrasher",
	"Pistol Savage",
	"Mad Frog",
	"Crank Lion",
	"Street Hobo",
	"Aimthod",
	"Amelchoi",
	"Araight",
	"ArticleLime",
	"BigClear",
	"Bitlthm",
	"Cheeserary",
	"Chiquitype",
	"Coopeatic",
	"Coundeme",
	"Eatella",
	"Editrace",
	"Featurensgr",
	"Finestambl",
	"Fulliali",
	"GlaceWarm",
	"GreeGroup",
	"HockeyTalented",
	"Hoopharo",
	"KinoDouble",
	"Linlion",
	"Lithostre",
	"Olymprebt",
	"Oniangwe",
	"Sibionic",
	"Somedg",
	"Thegpic",
	"Veecoutio",
	"Venistard",
	"WickedLawn",
	"Admindal",
	"Aliasse",
	"Allicake",
	"Awayim",
	"Blackers",
	"Caleafil",
	"Chargen",
	"DubyaWel",
	"Heroni",
	"HiroDubya",
	"HomeyPrime",
	"Icyde",
	"IncaSaiyan",
	"InsightMiss",
	"IssueBlab",
	"LatestSporks",
	"Logetic",
	"MohawkLola",
	"Mortezer",
	"Napasia",
	"Papignon",
	"Planetteho",
	"PlusExclusive",
	"ReporterCover",
	"Spoonse",
	"Teenagest",
	"TimesRider",
	"UpforTrimble",
	"Washelog",
	"Wizbe",
	"Amyly",
	"CatCetic",
	"DemonTrump",
	"Eurappe",
	"Feardy",
	"Goodexam",
	"HorrayMessages",
	"Horrayne",
	"IceBoa",
	"InfamousLil",
	"Inklear",
	"Keeperti",
	"Luvfe",
	"Majerede",
	"MdoggHear",
	"Neverma",
	"Osysiane",
	"Planet2cool",
	"Robbera",
	"Sadnorig",
	"Scanes",
	"SleekSkater",
	"TalentedZap",
	"ThrillBal",
	"Trannymo",
	"Uniserv",
	"Unta",
	"VampWaves",
	"Veganad",
	"Vinerspl",
	"Analyme",
	"Cartoonsmo",
	"CompareDrama",
	"Diaryzara",
	"DigestBuzz",
	"Directus",
	"Echorner",
	"ExtraDaily",
	"Geryzing",
	"Hometa",
	"InCharter",
	"InfoLens",
	"Machineur",
	"Onlyzing",
	"OriginalAdvice",
	"Picturcess",
	"Pictureness",
	"Picturesperf",
	"Primentru",
	"Quadronet",
	"Quatedge",
	"ReportsAspect",
	"Rolldo",
	"Selectond",
	"Selectsoni",
	"Speciallw",
	"Stephar",
	"StoryData",
	"Talker",
	"TipsMill",
	"lol",
	"xD",
	"u suck",
	"my balls",
];


function shuffleArray(array) {
	for (let i = array.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[array[i], array[j]] = [array[j], array[i]];
	}
}

let players = [];

const joinGame = (am = 1, region = "na", zone = "nyc", mode = "solos", mobile = "false") => {
	request.post(
		"https://surviv2.io/api/find_game",
		{
			json: true,
			body: {
				version: getModule("989ad62a").protocolVersion,
				region: region.toLowerCase() || "na",
				zones: [zone || "nyc"],
				playerCount: 1,
				autoFill: !0,
				gameModeIdx: mode.match(/solo/)
					? 0
					: mode.match(/duo/)
						? 1
						: mode.match(/squad/)
							? 2
							: 0,
				isMobile: mobile == "true",
			},
			timeout: 1e4,
			headers: {
				"Origin": "https://surviv2.io/",
				"User-Agent":
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.9 Safari/537.36",
			},
		},
		(err, res, body) => {
			if (err) return console.log(err);

			var a = body.res[0];

			console.log(a.gameId);

			var connect = (name) => {
				if (a && a.hosts && a.addrs) {
					var host = a.hosts[0];
					var ws = new WebSocket(
						"wss://" + host + "/play?gameId=" + a.gameId
					);
					var p = getModule("300e2704");

					var playa;

					var send = (e, t, a) => {
						var i = a || 128,
							r = new p.MsgStream(new ArrayBuffer(i));
						r.serializeMsg(e, t);

						if (ws && ws.readyState === ws.OPEN)
							try {
								var x = r.getBuffer();
								ws.send(x);
							} catch (e) {
								console.log(e);
								ws.close();
							}
					};
					var Ia = (e) => {
						for (var s = 0; s < e.delObjIds.length; s++)
							e.delObjIds[s], objs.deleteObj(e.delObjIds[s]);
						for (var l = 0; l < e.fullObjects.length; l++) {
							var c = e.fullObjects[l];
							objs.updateObjFull(c.__type, c.__id, c);
						}
						for (var m = 0; m < e.partObjects.length; m++) {
							var p = e.partObjects[m];
							objs.updateObjPart(p.__id, p);
						}
					};
					var objs = new Creator();
					var map;
					var id;
					var places;
					var saidPlace = false;

					var gasRad;
					var gasPos;
					var dead;

					var move = (dir, dist = 1) => {
						var z = new p.InputMsg();

						seq = (seq + 1) % 256;

						z.seq = seq;
						z.touchMoveActive = false;
						!!dir &&
							(z.touchMoveDir = {
								x: Math.cos(dir),
								y: Math.sin(dir),
							}) &&
							(z.toMouseDir = {
								x: Math.cos(dir),
								y: Math.sin(dir),
							}) &&
							(z.touchMoveActive = true) &&
							(z.touchMoveLen =
								dist < 1
									? dist < 0.5
										? 0
										: 255 * dist * dist * dist
									: 255 * dist);

						send(p.Msg.Input, z, 128);
					};
					var findDist = (p1, p2) => {
						var xs = p2.x - p1.x,
							ys = p2.y - p1.y;

						xs *= xs;
						ys *= ys;

						return Math.sqrt(xs + ys);
					};
					var findAngle = (p1, p2) => {
						var dy = p1.y - p2.y;
						var dx = p1.x - p2.x;
						var theta = Math.atan2(dy, dx); // range (-PI, PI]

						return theta;
					};
					var goToBush = () => {
						if (!map || !id || !places || !gasPos) return;

						var player = objs.getObjById(id);
						if (!player) return
						players[playa] = dead
							? false
							: {
								x: player.pos.x,
								y: player.pos.y,
								/*enemies: Object.values(objs.idToObj)
									.filter(e => !e.type && e.id != id)
									.map(e => e.pos)*/
							};
						const dir = findAngle(gasPos, player.pos)
						const dist = findDist(player.pos, gasPos)
						move(dir, dist)
					};

					var msg = (x, m) => {
						switch (x) {
							case p.Msg.Joined:
								var a = new p.JoinedMsg();
								a.deserialize(m);
								id = a.playerId;
								//process.stdout.write("\n0 Alive");
								playa =
									players.push({ x: 0, y: 0, enemies: [] }) -
									1;
								break;
							case p.Msg.Map:
								var a = new p.MapMsg();
								a.deserialize(m);
								map = a.objects;
								places = a.places;

								break;
							case p.Msg.Update:
								var a = new p.UpdateMsg();
								a.deserialize(m, objs);
								Ia(a);
								goToBush();

								if (a.gasData.radNew) gasRad = a.gasData.radNew;
								if (a.gasData.posNew) gasPos = a.gasData.posNew;

								break;
							case p.Msg.Kill:
								var a = new p.KillMsg();
								a.deserialize(m);
								break;
							case p.Msg.RoleAnnouncement:
								var a = new p.RoleAnnouncementMsg();
								a.deserialize(m);
								break;
							case p.Msg.PlayerStats:
								var a = new p.PlayerStatsMsg();
								a.deserialize(m);
								break;
							case p.Msg.Stats:
								var a = new p.StatsMsg();
								a.deserialize(m);
								//anticheat(atob(a.data));
								break;
							case p.Msg.GameOver:
								var a = new p.GameOverMsg();
								a.deserialize(m);
								console.log("dead", name);
								dead = true;
								ws.close();
								goToBush();
								break;
							case p.Msg.Pickup:
								var a = new p.PickupMsg();
								a.deserialize(m);
								break;
							case p.Msg.UpdatePass:
								var a = new p.UpdatePassMsg();
								a.deserialize(m);
								break;
							case p.Msg.AliveCounts:
								var a = new p.AliveCountsMsg();
								a.deserialize(m);
								//print(a.teamAliveCounts[0]);
								break;
							case p.Msg.Disconnect:
								var a = new p.DisconnectMsg();
								a.deserialize(m);
								dead = true;
								ws.close();
								break;
						}
					};
					var seq = 0;

					ws.binaryType = "arraybuffer";
					ws.onmessage = (e) => {
						for (var t = new p.MsgStream(e.data); ;) {
							var a = t.deserializeMsgType();
							if (a == p.Msg.None) break;
							msg(a, t.getStream());
						}
					};
					ws.onopen = () => {
						var i = new p.JoinMsg();

						i.protocol = data.protocolVersion;
						i.name = name;
						i.matchPriv = a.data;

						send(p.Msg.Join, i, 8192);
					};
					ws.onerror = (e) => {
						console.log("l", e);
					};

					//setInterval(update, 800);
				}
			};

			shuffleArray(names);

			for (var i = 0; i < am; i++) {
				connect(
					(Math.random() < 0.2
						? names[i].toLowerCase()
						: Math.random() > 0.8
							? names[i].toUpperCase()
							: names[i]) + (Math.random() < 0.05 ? "YT" : "")
				);
			}
		}
	);

	console.log("Joining", am, region, zone, mode);
};

wss.on("connection", (socket) => {
	console.log("hi");
	players = [];

	setInterval(() => {
		socket.send(JSON.stringify(players));
	}, 1000 / 5);

	socket.on("message", (m) => {
		joinGame(argv.amount, argv.region, argv.zone, !!m ? m : argv.mode, argv.mobile);
	});
});
