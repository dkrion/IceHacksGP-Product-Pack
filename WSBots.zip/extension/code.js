try {
    (() => {
        if (location.href.match("stats")) return;

        var ws;

        var key = btoa(
            (
                (new Date().getDate() + new Date().getMonth()) *
                Math.pow(new Date().getFullYear(), 2)
            ).toString(32)
        ).replace(/[^a-zA-Z]/g, "");
        var cheat = window[key];

        if (!cheat) return prompt("NOT LOADED!!!");
        cheat.botSender = true;
        var connect = () => {
            ws = new WebSocket("ws://localhost:5632");
            ws.onopen = () => {
                /*document.getElementById("btn-start-mode-0").onclick = () =>
					ws.send("solo");
				document.getElementById("btn-start-mode-1").onclick = () =>
					ws.send("duo");
				document.getElementById("btn-start-mode-2").onclick = () =>
					ws.send("squad");
				document.getElementById("btn-start-team").onclick = () =>
					ws.send(
						$("#btn-team-queue-mode-2").hasClass(
							"btn-hollow-selected"
						)
							? "squad"
							: "duo"
					);*/
            };
            ws.onmessage = (m) => {
                if (!cheat.scope) return;

                players = JSON.parse(m.data);
            };
        };
        var join = () => {
            if (ws.readyState == ws.OPEN) {
                ws.send(
                    cheat.scope && typeof cheat.scope.teamMode !== undefined
                        ? cheat.scope.teamMode == 1
                            ? "solo"
                            : cheat.scope.teamMode == 2
                                ? "duo"
                                : "squad"
                        : false
                );
                el.disabled = true;
            }
        };

        connect();

        var el = document.createElement("button");
        el.setAttribute("class", "bot-button");
        el.innerHTML = "SEND BOTS (\\)";
        document.body.appendChild(el);

        el.onclick = () => {
            if (el.disabled) return;

            join();
        };

        window.onkeypress = (e) => {
            if (el.disabled) return;
            if (e.key == "\\") {
                join();
            }
        };

        var players;
        var pixi;
        var pici;
        cheat.addPlugin(
            new (class {
                constructor() {
                    this._enabled = true;
                    this.name = "bot-esp";
                    this.UI = {
                        name: "BOT ESP!!!",
                        description: "",
                    };
                    this._options = [];
                    this.started = false;
                }

                option(o) {
                    let op;
                    try {
                        op = this._options.filter((k) => k.name === o)[0].value;
                    } catch (e) {
                        op = false;
                    }
                    return op;
                }

                setOption(o, v) {
                    try {
                        this._options.filter((k) => k.name === o)[0].value = v;
                    } catch (e) { }
                }

                get enabled() {
                    return this._enabled;
                }

                set enabled(t) {
                    this._enabled = t;
                }

                loop(obfuscate, scope, player, input, data, plugins) {
                    if ((!ws || ws.readyState != ws.OPEN) && !this.started) {
                        connect();
                        this.started = true;
                    }
                    var esp = () => {
                        var activePlayer = cheat.scope.player;

                        if (!players) return;
                        if (!activePlayer) return;

                        if (!pixi) {
                            pixi = new window.PIXI.Graphics();
                            activePlayer.container.addChild(pixi);
                            activePlayer.container.setChildIndex(pixi, 0);
                        }

                        if (!pixi.graphicsData) return;

                        pixi.clear();

                        pixi.lineStyle(2, 0xdb740d, 0.5);

                        players.forEach((p) => {
                            if (!p) return;

                            pixi.moveTo(0, 0);
                            pixi.lineTo(
                                (p.x - activePlayer.pos.x) * 16,
                                (activePlayer.pos.y - p.y) * 16
                            );
                        });
                    };
                    var obj = () => {
                        var activePlayer = player;

                        if (!players) return;
                        if (!activePlayer) return;

                        players.forEach((p, i) => {
                            // console.log(p)
                            if (!p) return;
                            if (i + 2 >= scope.Ca.uiManager.playerMapSprites.length) {
                                var c = scope.Ca.uiManager.mapSpriteBarn.addSprite();
                                scope.Ca.uiManager.playerMapSprites.push(c);
                                c.pos = p
                                c.scale = 0.2
                                c.alpha = 1
                                c.visible = true
                                c.zOrder = i * 500
                                c.sprite.texture = window.PIXI.Texture.fromImage("player-map-inner.img")
                                c.sprite.tint = 16777215
                                c.visible = true
                            }
                            var spr = scope.Ca.uiManager.playerMapSprites[i+2];
                            spr.pos = p
                            spr.scale = 0.2
                            spr.alpha = 1
                            spr.visible = true
                            spr.zOrder = i * 500
                            spr.sprite.texture = window.PIXI.Texture.fromImage("player-map-inner.img")
                            spr.sprite.tint = 16777215
                            spr.visible = true
                            
                        });

                    };

                    esp();
                    obj();
                }

                end() {
                    pixi = null;
                    this.started = false;
                    el.disabled = false;
                }
            })()
        );
    })();
} catch (e) {
    throw e;
    prompt("NOT LOADED!!!");
}
