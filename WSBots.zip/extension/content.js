function scriptAdd(name) {
	var el = document.createElement("script");
	el.setAttribute("src", chrome.runtime.getURL(`/${name}.js`));
	document.body.appendChild(el);
}
function stylesheetAdd(name, load) {
	var el = document.createElement("link");
	el.setAttribute("rel", "stylesheet");
	el.setAttribute("href", chrome.runtime.getURL(`/${name}.css`));
	document.head.appendChild(el);

	el.onload = load;
}
document.addEventListener("DOMContentLoaded", function() {
	stylesheetAdd("ui", () => {
		[...document.getElementsByTagName("link")].filter(e =>
			e.href.match("theme")
		).disabled = true;
		[...document.getElementsByTagName("link")].filter(e =>
			e.href.match("ui")
		).disabled = true;
		[...document.getElementsByTagName("link")].filter(e =>
			e.href.match("ui")
		).disabled = false;
	});
	setTimeout(() => scriptAdd("code"), 1000);
});
