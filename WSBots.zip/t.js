var p = {};

global.webpackJsonp = (a, b, c) => {
	p = Object.assign(p, b);
};

global.atob = function(text) {
	var buf = Buffer.from(text, "base64");
	var bytes = [];
	for (var i = buf.length; i >= 0; i--) {
		bytes[i] = String.fromCharCode(buf[i]);
	}

	return bytes.join("");
};

global.btoa = t => {
	return Buffer.from(t).toString("base64");
};

global.getModule = k => {
	var o = {};

	if (typeof p[k] !== "function") {
		switch (k) {
			case "0e566746":
				return (a, b) => {
					a || console.log(b);
				};
				break;
			case "a5e2faae":
				return { Buffer };
				break;
			case "991178d3":
				return require("crypto");
				break;
			case "1f15ac6e":
				return JSON.stringify;
				break;
			case "f05b4d6a":
				return Object.keys;
				break;
			case "7400a140":
				return function(e, t) {
					if (!(e instanceof t))
						throw new TypeError(
							"Cannot call a class as a function"
						);
				};
				break;
			case "8f1e0713":
				return (function() {
					var i = {
						default: function(e, t, r) {
							return Object.defineProperty(e, t, r);
						}
					};
					function e(e, t) {
						for (var r = 0; r < t.length; r++) {
							var n = t[r];
							(n.enumerable = n.enumerable || !1),
								(n.configurable = !0),
								"value" in n && (n.writable = !0),
								(0, i.default)(e, n.key, n);
						}
					}
					return function(t, r, n) {
						return r && e(t.prototype, r), n && e(t, n), t;
					};
				})();
				break;
			case "8ee62bea":
				return require("jquery")();
				break;
		}

		console.log(k);
	}

	if (k == "753d6e4b") console.log(p[k]);

	p[k](o, null, k => {
		return getModule(k);
	});

	return o.exports;
};

module.exports = p;
